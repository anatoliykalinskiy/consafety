import { Component } from '@angular/core';

@Component({
  selector: 'app-singUp',
  templateUrl: './sing-up.component.html',
  styleUrls: ['./sing-up.component.css']
})
export class SingUp {
  title = 'Sing Up Page';
}