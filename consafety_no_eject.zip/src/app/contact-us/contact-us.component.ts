import { Component } from '@angular/core';

@Component({
  selector: 'app-contactUs',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent {
  title = 'Contact Us Page';
}
