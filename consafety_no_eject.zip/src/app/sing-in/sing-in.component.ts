import { Component } from '@angular/core';

@Component({
  selector: 'app-singIn',
  templateUrl: './sing-in.component.html',
  styleUrls: ['./sing-in.component.css']
})
export class SingIn {
  title = 'Sing In Page';
}